#include "Pieces.h"

Pieces::Pieces()
{
}


Pieces::~Pieces()
{
}
