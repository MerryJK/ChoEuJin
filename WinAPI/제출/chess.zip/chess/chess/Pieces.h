#pragma once
#include "BitMapManager.h"

class Pieces
{
public:
	Pieces();
	~Pieces();
};

