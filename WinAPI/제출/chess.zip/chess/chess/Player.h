#pragma once
#include "Pieces.h"

class Player
{
public:
	Player();
	~Player();
};

