#pragma once
#include"CardManager.h"

class GameManager
{
private:
	CardManager CM;
	int m_iCurCardType;
	int m_iPreCardType;
	bool m_bPauseMatch;
public:
	GameManager();
	void InIt(HWND, HINSTANCE);
	void DrawGame(HDC);
	void PlayGame(HWND, POINT);
	void CloseCards(HWND);
	~GameManager();
};

